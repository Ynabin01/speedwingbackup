<!DOCTYPE html>
<html>
<head>
    <title>New Subscribe Request</title>
    <style>

    </style>
</head>
<body>

<h1><span style="color: #008080;"><strong>Khabari Nepal</strong></span></h1>
<h4><span style="color: #008080;"><strong>Anamnagar, Kathmandu</strong></span></h4>
<p><span style="color: #008080;"><strong>Your have Subscription request from:</strong></span></p>
<table>
    <tbody>
    <tr>
        <td style="width: 148px;"><strong>Email :</strong></td>
        <td style="width: 407px;"><strong>{{$data['email']?$data['email']:''}}</strong></td>
    </tr>
    </tbody>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
</body>
</html>


