<!DOCTYPE html>
<html>
<head>
    <title>Thank you for subscribing us.</title>
    <style>

    </style>
</head>
<body>

<h1><span style="color: #008080;"><strong>Khabari Nepal</strong></span></h1>
<h4><span style="color: #008080;"><strong>Anamnagar, Kathmandu</strong></span></h4>
<p><span><strong>Thank you for Subscription</strong></span></p>

<p>Regards</p>
<p>Khabari Nepal</p>
</body>
</html>


