<p><span style="font-size:26px"><span style="color:#27ae60"><strong>Name</strong> :-</span>
    <em>
     {{$data['name']}}
    </em></span></p>

<p><span style="font-size:18px">Email : {{ $data['email']}}</span></p>

<p><span style="font-size:18px">phone No : {{ $data['number']}}
</span></p>

<hr />
<p style="margin-left:40px">{{ $data['message']}}</p>
