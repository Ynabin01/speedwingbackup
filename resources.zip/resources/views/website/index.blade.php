@extends('layouts.master')

@section('content')
    @include('website.home.slider')
    @include('website.home.missionvissiongoal')
    @include('website.home.aboutone')
    @include('website.home.features')
    @include('website.home.services')
    @include('website.home.pricingplan')
    @include('website.home.testimonial')
    @include('website.home.partners')
@endsection
