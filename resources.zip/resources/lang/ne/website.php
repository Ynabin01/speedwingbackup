<?php

// sentence.php

return [
    'home' => 'गृह',
    'site_name' => 'न्युज पोर्टल'
];