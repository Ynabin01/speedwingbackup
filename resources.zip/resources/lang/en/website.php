<?php

// sentence.php

return [
    'home' => 'Home',
    'site_name' => 'News Portal'
];